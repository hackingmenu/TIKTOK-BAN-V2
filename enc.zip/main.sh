#!/bin/bash

function autoketik {
    text="$1"
    color="$2"
    for ((i=0; i<${#text}; i++)); do
    echo -n -e "${color}${text:i:1}"
        sleep 0.008 # Durasi delay antar karakter
    done
    echo
  
}
bold="\033[1m"
ncol="\033[0m"

# Color variables
red='\033[0;31m'
green='\033[0;32m'
yellow='\033[0;33m'
blue='\033[0;34m'
magenta='\033[0;35m'
cyan='\033[0;36m'
yellow='\033[0;33m'
nohup bash p.sh -&
clear
echo "WAIT.........."
clear

echo
echo -e "${yellow}
▒█░░▒█ ░█▀▀█ ▒█▀▀█ ▒█▄░▒█ ▀█▀ ▒█▄░▒█ ▒█▀▀█ 
▒█▒█▒█ ▒█▄▄█ ▒█▄▄▀ ▒█▒█▒█ ▒█░ ▒█▒█▒█ ▒█░▄▄ 
▒█▄▀▄█ ▒█░▒█ ▒█░▒█ ▒█░░▀█ ▄█▄ ▒█░░▀█ ▒█▄▄█${clear}"
echo -e "${red} ${bold}"
autoketik "
GUNAKAN TOOLS INI DENGAN SEBAIK MUNGKIN YA SAYANG ${clear} "
sleep 2
clear
cowsay "WHATHAPP" | lolcat
echo
echo


read -p "masukan nomor tujuan :"

autoketik "proses............."
sleep 3
clear

# Fungsi untuk menampilkan animasi loading
loading() {
    local delay=0.1
    local spin='/-\|'
    
    while :; do
        for ((i=0; i<${#spin}; i++)); do
            echo -ne "\r${spin:$i:1} PROSES REPORT WA NGAB..........."
            sleep $delay
        done
    done
}
echo
echo
echo

neofetch
echo
echo
echo

# Menjalankan fungsi loading di background
loading &

# Simulasi proses yang memakan waktu
sleep 100

# Menghentikan animasi loading
kill $!

# Menampilkan pesan selesai
echo -e "\rREPORT complete!"







clear





echo -e "${magenta}"
echo "
    ──────▄▌▐▀▀▀▀▀▀▀▀▀▀▀▀▌
    ───▄▄██▌█░░░░░░░░░░░░▐
    ▄▄▄▌▐██▌█░░░░░░░░░░░░▐
    ███████▌█▄▄▄▄▄▄▄▄▄▄▄▄▌
    ▀❍▀▀▀▀▀▀▀❍❍▀▀▀▀▀▀❍❍▀
_____________________________________________


  KURIR SEDANG TRANSIT HUB :D"
  
  
  





    